MusicMap — Machine Learning Course Project
Veermata Jijabai Technological Institute (VJTI)
Academic Year 2026–27, T.Y. B.Tech. CE, Semester V

Students:
Akshat Tikaria — Roll number 241070005
Aniket Shinde — Roll number 171070977

Files:
1. MusicMap_Project_Report_Akshat_Aniket.pdf — final 18-page report for submission.
2. MusicMap_Project_Report_Akshat_Aniket.docx — editable Word copy of the same report.
3. FMA_2017_Reference_Paper_Author_Version.pdf — the principal reference paper.
4. FMA_Paper_License_CC_BY_4.0.txt — authors' license for the attached reference.

The project report follows the assignment sections: Introduction, Problem Statement,
Dataset Description, Algorithm Details, Training Information, Results and Analysis,
Conclusion, and References. It also includes a cover, contents and abstract.

The measurements are taken from the verified MusicMap project artifacts at:
https://github.com/akshattikaria/ML_MUSIC_PROJECT_BY_AKSHAT_AND_ANIKET
Revision: 6d30df1b792a5df45abd9aab5984c8fec351afa1
Classification: 50.375% top-1 accuracy, 0.4987 macro F1 and 80.375% top-3 accuracy.

Reference paper provenance:
Michaël Defferrard, Kirell Benzi, Pierre Vandergheynst and Xavier Bresson,
"FMA: A Dataset for Music Analysis," ISMIR, 2017.
https://arxiv.org/abs/1612.01840

The attached PDF is compiled from the authors' unmodified, publicly available
CC BY 4.0 LaTeX source and figures at:
https://github.com/mdeff/paper-fma-ismir2017
Source revision: 400b5e3905c59cf94088f88832f2c621039ae52f
It is labelled an author version and is not represented as a downloaded publisher PDF.
Attribution and the source license are included. The project report's other scholarly
references are listed in Section 8 with citations; the attachment is the main dataset paper.

For Classroom submission, upload the final report PDF and attach the reference-paper PDF
separately if requested. The Word file is provided for editing, not required to read the report.
The files have not been uploaded to Classroom or submitted on your behalf.
